// ─────────────────────────────────────────────────────────
//  neXus — Assistente Financeiro para WhatsApp
//  Deploy: Railway (free tier)
//  DB:     Turso (SQLite na nuvem, free tier)
//  Plano Básico  R$ 29,90/mês
//  Plano Pro     R$ 47,90/mês
// ─────────────────────────────────────────────────────────

const express = require("express");
const { createClient } = require("@libsql/client");
const Anthropic = require("@anthropic-ai/sdk");
const Stripe = require("stripe");
const axios = require("axios");
const path = require("path");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

// ─── CLIENTES ─────────────────────────────────────────────
const db = createClient({
  url:       process.env.TURSO_DATABASE_URL,
  authToken: process.env.TURSO_AUTH_TOKEN,
});

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const stripe    = new Stripe(process.env.STRIPE_SECRET_KEY);

// ─── BANCO DE DADOS ───────────────────────────────────────
async function initDB() {
  await db.executeMultiple(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT UNIQUE NOT NULL,
      name TEXT,
      stripe_customer_id TEXT,
      stripe_subscription_id TEXT,
      plan TEXT DEFAULT 'none',
      status TEXT DEFAULT 'trial',
      trial_end INTEGER,
      created_at INTEGER DEFAULT (unixepoch())
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_phone TEXT NOT NULL,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      category TEXT,
      description TEXT,
      month TEXT,
      created_at INTEGER DEFAULT (unixepoch())
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_phone TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at INTEGER DEFAULT (unixepoch())
    );
  `);
  console.log("✦ Banco Turso inicializado");
}

// ─── HELPERS ──────────────────────────────────────────────
async function getOrCreateUser(phone) {
  const res = await db.execute({ sql: "SELECT * FROM users WHERE phone = ?", args: [phone] });
  if (res.rows.length > 0) return res.rows[0];

  const trialEnd = Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60;
  await db.execute({
    sql:  "INSERT INTO users (phone, trial_end, status, plan) VALUES (?, ?, 'trial', 'pro')",
    args: [phone, trialEnd],
  });
  const created = await db.execute({ sql: "SELECT * FROM users WHERE phone = ?", args: [phone] });
  return created.rows[0];
}

function isUserActive(user) {
  if (user.status === "active") return true;
  if (user.status === "trial" && user.trial_end > Math.floor(Date.now() / 1000)) return true;
  return false;
}

function isPro(user) {
  if (user.status === "trial") return true;
  return user.plan === "pro" && user.status === "active";
}

async function getUserHistory(phone, limit = 10) {
  const res = await db.execute({
    sql:  "SELECT role, content FROM messages WHERE user_phone = ? ORDER BY created_at DESC LIMIT ?",
    args: [phone, limit],
  });
  return res.rows.reverse();
}

async function saveMessage(phone, role, content) {
  await db.execute({
    sql:  "INSERT INTO messages (user_phone, role, content) VALUES (?, ?, ?)",
    args: [phone, role, content],
  });
}

function getCurrentMonth() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

async function getMonthSummary(phone, month = getCurrentMonth()) {
  const [income, expense, byCategory, allExpenses] = await Promise.all([
    db.execute({ sql: "SELECT COALESCE(SUM(amount),0) as total FROM transactions WHERE user_phone=? AND type='income' AND month=?",  args: [phone, month] }),
    db.execute({ sql: "SELECT COALESCE(SUM(amount),0) as total FROM transactions WHERE user_phone=? AND type='expense' AND month=?", args: [phone, month] }),
    db.execute({ sql: "SELECT category, SUM(amount) as total FROM transactions WHERE user_phone=? AND type='expense' AND month=? GROUP BY category ORDER BY total DESC", args: [phone, month] }),
    db.execute({ sql: "SELECT description, amount, category FROM transactions WHERE user_phone=? AND type='expense' AND month=? ORDER BY amount DESC", args: [phone, month] }),
  ]);
  return {
    income:      Number(income.rows[0].total),
    expense:     Number(expense.rows[0].total),
    byCategory:  byCategory.rows,
    allExpenses: allExpenses.rows,
  };
}

// ─── ENVIAR MENSAGEM WA ───────────────────────────────────
async function sendWhatsApp(phone, message) {
  try {
    await axios.post(
      `${process.env.EVOLUTION_API_URL}/message/sendText/${process.env.EVOLUTION_INSTANCE}`,
      { number: phone, text: message },
      { headers: { apikey: process.env.EVOLUTION_API_KEY } }
    );
  } catch (err) {
    console.error("Erro WA:", err.message);
  }
}

// ─── SYSTEM PROMPT BÁSICO ─────────────────────────────────
function systemBasic(user, summary) {
  const trialDays = user.status === "trial"
    ? Math.ceil((user.trial_end - Date.now() / 1000) / 86400) : 0;

  return `Você é o neXus, assistente financeiro no WhatsApp. Seja direto e eficiente.

USUÁRIO: ${user.name || "usuário"} | Plano: Básico | Status: ${user.status}${user.status === "trial" ? ` (trial — ${trialDays} dias restantes)` : ""}

RESUMO ${getCurrentMonth()}:
- Receitas: R$ ${Number(summary.income).toFixed(2)}
- Gastos:   R$ ${Number(summary.expense).toFixed(2)}
- Saldo:    R$ ${(Number(summary.income) - Number(summary.expense)).toFixed(2)}
- Categorias: ${summary.byCategory.map(c => `${c.category}: R$${Number(c.total).toFixed(2)}`).join(" | ") || "nenhum"}

CAPACIDADES DO PLANO BÁSICO:
1. Registrar gastos e receitas
2. Mostrar resumo e saldo do mês
3. Listar gastos por categoria

FORMATO — para registrar transação, primeira linha SEMPRE o JSON de ação:
ACTION:{"type":"expense","amount":50,"category":"Alimentação","description":"mercado"}
Anotado! 🛒 R$ 50,00 em Alimentação.

Para receita:
ACTION:{"type":"income","amount":3000,"category":"Salário","description":"salário"}
💰 R$ 3.000,00 registrado.

CATEGORIAS: Alimentação, Transporte, Moradia, Saúde, Lazer, Educação, Contas, Roupas, Salário, Freelance, Outros

REGRAS:
- Mensagens curtas. WhatsApp não é e-mail.
- Se pedir análise ou conselho, informe que é exclusivo do Pro (R$ 47,90/mês): ${process.env.APP_URL}/assinar?phone=${user.phone}&upgrade=1
- Se trial < 2 dias, mencione sutilmente no final.`;
}

// ─── SYSTEM PROMPT PRO ────────────────────────────────────
function systemPro(user, summary) {
  const trialDays = user.status === "trial"
    ? Math.ceil((user.trial_end - Date.now() / 1000) / 86400) : 0;

  const expenseDetail = summary.allExpenses.length
    ? summary.allExpenses.map(e => `- R$${Number(e.amount).toFixed(2)} em "${e.description}" (${e.category})`).join("\n")
    : "nenhum gasto registrado ainda";

  return `Você é o neXus, assistente financeiro e consultor pessoal no WhatsApp.

USUÁRIO: ${user.name || "usuário"} | Plano: Pro ⭐ | Status: ${user.status}${user.status === "trial" ? ` (trial — ${trialDays} dias restantes)` : ""}

RESUMO ${getCurrentMonth()}:
Receitas: R$ ${Number(summary.income).toFixed(2)}
Gastos:   R$ ${Number(summary.expense).toFixed(2)}
Saldo:    R$ ${(Number(summary.income) - Number(summary.expense)).toFixed(2)}

CATEGORIAS:
${summary.byCategory.map(c => `${c.category}: R$${Number(c.total).toFixed(2)}`).join("\n") || "nenhum"}

TODOS OS GASTOS DO MÊS:
${expenseDetail}

CAPACIDADES PRO:
1. Registrar gastos e receitas
2. Resumo, saldo e categorias
3. Analisar gastos desproporcionais ou desnecessários
4. Conselhos práticos baseados nos dados reais
5. Sugerir metas de economia concretas

FORMATO — registrar transação:
ACTION:{"type":"expense","amount":50,"category":"Alimentação","description":"mercado"}
Anotado! 🛒 R$ 50,00 em Alimentação.

Para receita:
ACTION:{"type":"income","amount":3000,"category":"Salário","description":"salário"}
💰 R$ 3.000,00 registrado.

REGRAS:
- Mensagens objetivas, máximo 5 parágrafos curtos.
- Ao apontar gastos desnecessários, seja gentil mas honesto.
- Use sempre os valores reais dos gastos listados acima.
- Se trial < 2 dias, mencione sutilmente no final.`;
}

// ─── PROCESSAR COM IA ─────────────────────────────────────
async function processWithAI(phone, userMessage) {
  const user = await getOrCreateUser(phone);

  if (!isUserActive(user)) {
    return `⛔ *Seu período de teste encerrou.*\n\nPara continuar usando o neXus:\n\n✦ *Básico* — R$ 29,90/mês\nRegistro de gastos e resumos\n\n✦ *Pro* — R$ 47,90/mês\nBásico + consultoria financeira com IA\n\n👉 ${process.env.APP_URL}/assinar?phone=${phone}\n\nSeu histórico está salvo e volta assim que você assinar.`;
  }

  const [summary, history] = await Promise.all([
    getMonthSummary(phone),
    getUserHistory(phone, 8),
  ]);

  const systemPrompt = isPro(user) ? systemPro(user, summary) : systemBasic(user, summary);

  const messages = [
    ...history.map(m => ({ role: m.role, content: m.content })),
    { role: "user", content: userMessage },
  ];

  const response = await anthropic.messages.create({
    model:      "claude-sonnet-4-20250514",
    max_tokens: 600,
    system:     systemPrompt,
    messages,
  });

  const assistantText = response.content[0].text;
  await Promise.all([
    saveMessage(phone, "user",      userMessage),
    saveMessage(phone, "assistant", assistantText),
  ]);

  if (assistantText.startsWith("ACTION:")) {
    const lines    = assistantText.split("\n");
    const jsonStr  = lines[0].replace("ACTION:", "").trim();
    const replyText = lines.slice(1).join("\n").trim();
    try {
      const action = JSON.parse(jsonStr);
      await db.execute({
        sql:  "INSERT INTO transactions (user_phone, type, amount, category, description, month) VALUES (?, ?, ?, ?, ?, ?)",
        args: [phone, action.type, action.amount, action.category, action.description, getCurrentMonth()],
      });
      return replyText;
    } catch {
      return assistantText.replace(/^ACTION:.*\n/, "");
    }
  }

  return assistantText;
}

// ─── WEBHOOK EVOLUTION API ────────────────────────────────
app.post("/webhook/whatsapp", async (req, res) => {
  res.sendStatus(200);
  const data = req.body;
  if (data.event !== "messages.upsert") return;
  const msg  = data.data?.messages?.[0];
  if (!msg || msg.key?.fromMe) return;
  const phone = msg.key?.remoteJid?.replace("@s.whatsapp.net", "");
  const text  = msg.message?.conversation || msg.message?.extendedTextMessage?.text;
  if (!phone || !text) return;
  console.log(`📨 ${phone}: ${text}`);
  try {
    const reply = await processWithAI(phone, text);
    await sendWhatsApp(phone, reply);
  } catch (err) {
    console.error("Erro:", err);
    await sendWhatsApp(phone, "Ops, erro interno. Tenta de novo! 🙏");
  }
});

// ─── PÁGINA DE ASSINATURA ─────────────────────────────────
app.get("/assinar", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/assinar.html"));
});

// ─── CRIAR CHECKOUT STRIPE ────────────────────────────────
app.post("/api/criar-checkout", async (req, res) => {
  const { phone, plan } = req.body;
  if (!phone || !plan) return res.status(400).json({ error: "phone e plan obrigatórios" });

  const priceId = plan === "pro" ? process.env.STRIPE_PRICE_PRO : process.env.STRIPE_PRICE_BASIC;
  const user    = await getOrCreateUser(phone);

  let customerId = user.stripe_customer_id;
  if (!customerId) {
    const customer = await stripe.customers.create({ metadata: { whatsapp: phone } });
    customerId = customer.id;
    await db.execute({ sql: "UPDATE users SET stripe_customer_id=? WHERE phone=?", args: [customerId, phone] });
  }

  const session = await stripe.checkout.sessions.create({
    customer:             customerId,
    mode:                 "subscription",
    payment_method_types: ["card"],
    line_items:           [{ price: priceId, quantity: 1 }],
    success_url:          `${process.env.APP_URL}/sucesso?phone=${phone}&plan=${plan}`,
    cancel_url:           `${process.env.APP_URL}/assinar?phone=${phone}`,
    metadata:             { phone, plan },
  });

  res.json({ url: session.url });
});

// ─── WEBHOOK STRIPE ───────────────────────────────────────
app.post("/webhook/stripe", express.raw({ type: "application/json" }), async (req, res) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook error: ${err.message}`);
  }

  const obj = event.data.object;

  if (event.type === "checkout.session.completed") {
    const phone = obj.metadata?.phone;
    const plan  = obj.metadata?.plan || "basic";
    if (phone) {
      await db.execute({
        sql:  "UPDATE users SET status='active', plan=?, stripe_subscription_id=? WHERE phone=?",
        args: [plan, obj.subscription, phone],
      });
      const planName = plan === "pro" ? "Pro ⭐" : "Básico";
      sendWhatsApp(phone, `✅ *Assinatura neXus ${planName} confirmada!*\n\nSeu assistente financeiro está ativo.\n\nComeça mandando: _"gastei 50 no mercado"_ 💼`);
    }
  }

  if (event.type === "customer.subscription.deleted" || event.type === "invoice.payment_failed") {
    const subId = obj.id || obj.subscription;
    await db.execute({ sql: "UPDATE users SET status='canceled' WHERE stripe_subscription_id=?", args: [subId] });
  }

  res.sendStatus(200);
});

// ─── SUCESSO ──────────────────────────────────────────────
app.get("/sucesso", (req, res) => {
  const plan = req.query.plan === "pro" ? "Pro ⭐" : "Básico";
  res.send(`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>neXus — Ativado!</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans&display=swap" rel="stylesheet">
<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;background:#0a0a0a;color:#f0e6c8;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem}.card{text-align:center;max-width:380px;padding:3rem 2rem;background:#111;border:1px solid rgba(212,175,55,0.25);border-radius:20px}.icon{font-size:3.5rem;margin-bottom:1.5rem}h1{font-family:'Syne',sans-serif;font-size:1.8rem;font-weight:800;color:#d4af37;margin-bottom:.75rem}p{color:#a89060;line-height:1.6}</style>
</head><body><div class="card"><div class="icon">✦</div><h1>Plano ${plan} ativado!</h1><p>Volte ao WhatsApp — o neXus já está esperando.</p></div></body></html>`);
});

// ─── ADMIN ────────────────────────────────────────────────
app.get("/admin/users", async (req, res) => {
  if (req.query.key !== process.env.ADMIN_KEY) return res.status(401).json({ error: "unauthorized" });
  const [users, revenue] = await Promise.all([
    db.execute("SELECT phone, name, plan, status, trial_end, created_at FROM users ORDER BY created_at DESC"),
    db.execute("SELECT plan, COUNT(*) as count FROM users WHERE status='active' GROUP BY plan"),
  ]);
  res.json({ users: users.rows, revenue: revenue.rows });
});

// ─── HEALTH CHECK (Railway precisa) ──────────────────────
app.get("/", (req, res) => res.json({ status: "ok", app: "neXus" }));

// ─── START ────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
initDB().then(() => {
  app.listen(PORT, () => {
    console.log(`\n✦ neXus rodando na porta ${PORT}`);
    console.log(`  Webhook WA:     POST /webhook/whatsapp`);
    console.log(`  Webhook Stripe: POST /webhook/stripe`);
    console.log(`  Admin:          GET  /admin/users?key=xxx\n`);
  });
}).catch(err => {
  console.error("Falha ao iniciar:", err);
  process.exit(1);
});
