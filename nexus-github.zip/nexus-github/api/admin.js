// api/admin.js — painel de usuários

const { initDB, getDB } = require("../lib/db");

export default async function handler(req, res) {
  if (req.query.key !== process.env.ADMIN_KEY) {
    return res.status(401).json({ error: "unauthorized" });
  }

  await initDB();
  const db = getDB();

  const [users, revenue] = await Promise.all([
    db.execute("SELECT phone, name, plan, status, trial_end, created_at FROM users ORDER BY created_at DESC"),
    db.execute("SELECT plan, COUNT(*) as count FROM users WHERE status='active' GROUP BY plan"),
  ]);

  res.json({ users: users.rows, revenue: revenue.rows });
}

export const config = { maxDuration: 10 };
