// api/criar-checkout.js — cria sessão de pagamento Stripe

const Stripe = require("stripe");
const { initDB, getDB, getOrCreateUser } = require("../lib/db");

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { phone, plan } = req.body;
  if (!phone || !plan) return res.status(400).json({ error: "phone e plan obrigatórios" });

  const priceId = plan === "pro" ? process.env.STRIPE_PRICE_PRO : process.env.STRIPE_PRICE_BASIC;

  try {
    await initDB();
    const db   = getDB();
    const user = await getOrCreateUser(phone);

    let customerId = user.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({ metadata: { whatsapp: phone } });
      customerId = customer.id;
      await db.execute({
        sql:  "UPDATE users SET stripe_customer_id=? WHERE phone=?",
        args: [customerId, phone],
      });
    }

    const session = await stripe.checkout.sessions.create({
      customer:             customerId,
      mode:                 "subscription",
      payment_method_types: ["card"],
      line_items:           [{ price: priceId, quantity: 1 }],
      success_url:          `${process.env.APP_URL}/sucesso?plan=${plan}`,
      cancel_url:           `${process.env.APP_URL}/assinar?phone=${phone}`,
      metadata:             { phone, plan },
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error("Checkout error:", err);
    res.status(500).json({ error: err.message });
  }
}

export const config = { maxDuration: 15 };
