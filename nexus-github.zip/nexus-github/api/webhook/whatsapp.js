// api/webhook/whatsapp.js — recebe mensagens da Evolution API

const axios = require("axios");
const { initDB } = require("../../lib/db");
const { processWithAI } = require("../../lib/ai");

async function sendWhatsApp(phone, message) {
  try {
    await axios.post(
      `${process.env.EVOLUTION_API_URL}/message/sendText/${process.env.EVOLUTION_INSTANCE}`,
      { number: phone, text: message },
      { headers: { apikey: process.env.EVOLUTION_API_KEY }, timeout: 8000 }
    );
  } catch (err) {
    console.error("Erro WA:", err.message);
  }
}

export default async function handler(req, res) {
  // Vercel precisa de resposta rápida — responde 200 imediatamente
  if (req.method !== "POST") return res.status(405).end();

  res.status(200).json({ ok: true });

  const data = req.body;
  if (data.event !== "messages.upsert") return;

  const msg = data.data?.messages?.[0];
  if (!msg || msg.key?.fromMe) return;

  const phone = msg.key?.remoteJid?.replace("@s.whatsapp.net", "");
  const text  = msg.message?.conversation || msg.message?.extendedTextMessage?.text;
  if (!phone || !text) return;

  console.log(`📨 ${phone}: ${text}`);

  try {
    await initDB();
    const reply = await processWithAI(phone, text);
    await sendWhatsApp(phone, reply);
  } catch (err) {
    console.error("Erro processando mensagem:", err);
    await sendWhatsApp(phone, "Ops, erro interno. Tenta de novo! 🙏");
  }
}

export const config = { maxDuration: 30 };
