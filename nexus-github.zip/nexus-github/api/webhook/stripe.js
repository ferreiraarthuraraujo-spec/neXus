// api/webhook/stripe.js — processa pagamentos

const Stripe = require("stripe");
const axios  = require("axios");
const { initDB, getDB } = require("../../lib/db");

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

async function sendWhatsApp(phone, message) {
  try {
    await axios.post(
      `${process.env.EVOLUTION_API_URL}/message/sendText/${process.env.EVOLUTION_INSTANCE}`,
      { number: phone, text: message },
      { headers: { apikey: process.env.EVOLUTION_API_KEY }, timeout: 8000 }
    );
  } catch (err) {
    console.error("Erro WA:", err.message);
  }
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const sig = req.headers["stripe-signature"];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook error: ${err.message}`);
  }

  await initDB();
  const db  = getDB();
  const obj = event.data.object;

  if (event.type === "checkout.session.completed") {
    const phone = obj.metadata?.phone;
    const plan  = obj.metadata?.plan || "basic";
    if (phone) {
      await db.execute({
        sql:  "UPDATE users SET status='active', plan=?, stripe_subscription_id=? WHERE phone=?",
        args: [plan, obj.subscription, phone],
      });
      const planName = plan === "pro" ? "Pro ⭐" : "Básico";
      sendWhatsApp(phone, `✅ *Assinatura neXus ${planName} confirmada!*\n\nSeu assistente financeiro está ativo.\n\nComeça mandando: _"gastei 50 no mercado"_ 💼`);
    }
  }

  if (event.type === "customer.subscription.deleted" || event.type === "invoice.payment_failed") {
    const subId = obj.id || obj.subscription;
    await db.execute({
      sql:  "UPDATE users SET status='canceled' WHERE stripe_subscription_id=?",
      args: [subId],
    });
  }

  res.status(200).json({ received: true });
}

// Stripe precisa do body raw para validar assinatura
export const config = { api: { bodyParser: false }, maxDuration: 15 };
